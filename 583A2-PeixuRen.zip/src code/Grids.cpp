//
//  Grids.cpp
//  583A2
//
//  Created by Peixu Ren on 2018-02-06.
//  Copyright © 2018 Peixu Ren. All rights reserved.
//

#include "Grids.hpp"

Grids::Grids()
{
    cell_No = -1;
    x = -1;
    y = -1;
    //blo_loc.x = -1;
    //blo_loc.y = -1;
}

Grids::~Grids()
{
    
}
